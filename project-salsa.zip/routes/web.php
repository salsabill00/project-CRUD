<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\PagesController;
use App\http\Controllers\StudentController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

route::get('/', [PagesController::class, 'home']);
route::get('/about', [PagesController::class, 'about']);
route::get('/contact', [PagesController::class, 'contact']);
route::get('/signin', [PagesController::class, 'signin']);
route::get('/dashboard', [PagesController::class, 'dashboard']);
route::get('/student', [StudentController::class, 'index']);
route::get('/student/create', [StudentController::class, 'create']);
route::post('/student', [StudentController::class, 'store']);
route::get('/{student}/edit', [StudentController::class, 'edit']);
route::patch('/student/{student}', [StudentController::class, 'update']);
route::get('/{student}/detail', [StudentController::class, 'show']);
route::get('/student/exportstudent', [StudentController::class, 'studentexport']);
route::delete('{student}', [StudentController::class, 'destroy']);
